My website URL: http://www-users.cselabs.umn.edu/~fangx205/login.php
The following account will always be in the database: 

login: JiananFang
password: 12345
